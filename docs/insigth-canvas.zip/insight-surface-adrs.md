# Architecture Decision Records: Insight Surface

---

## ADR-001: Insight Generation Architecture — Pre-Computation vs. On-Demand

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Engineering Lead, Data Science Lead, Product Lead

### Context

The Insight Surface product requires generating personalized insights from the GWI dataset for each user. There are two fundamental approaches: pre-computing insights in batch and serving them from a cache, or generating insights on-demand when a user opens the product.

### Decision

**Adopt a hybrid pre-computation model with on-demand refinement.**

- **Batch layer**: A scheduled pipeline runs after each data wave ingestion (and on a daily cadence for trend recalculation). This pipeline performs: anomaly detection across all dimensions, trend analysis with directional indicators, cross-dimensional correlation discovery, and competitive divergence analysis. Results are stored as a **global insight pool** — a set of unscored, unpersonalized insight candidates.

- **Personalization layer**: When a user opens the product, the personalization engine scores the global insight pool against the user's context model in real-time (< 500ms). This produces the ranked, personalized insight stream.

- **On-demand layer**: When a user pulls a thread (explores deeper into an insight), follow-up analyses are generated on-demand using pre-indexed data. Pre-computation of the most likely follow-ups is attempted but not guaranteed.

### Rationale

- Pure pre-computation per user doesn't scale — the combinatorial explosion of users × contexts × dimensions makes full pre-computation infeasible
- Pure on-demand generation creates unacceptable latency — complex statistical analysis cannot complete within UX-acceptable timeframes
- The hybrid model separates the expensive work (statistical analysis of the full dataset) from the personalization work (scoring and ranking against a context model), allowing each to scale independently
- The global insight pool creates a shared asset that amortizes compute cost across all users

### Consequences

- Requires a robust job scheduling and pipeline orchestration system
- The global insight pool needs a well-defined schema and storage strategy
- Personalization scoring must be highly optimized for real-time performance
- Thread exploration may occasionally show loading states when pre-computation hasn't covered a specific follow-up path
- Data freshness is bounded by batch pipeline cadence — insights cannot be more fresh than the most recent pipeline run

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Fully pre-computed per user | Doesn't scale; compute cost grows linearly with user base; stale if user context changes mid-session |
| Fully on-demand | Latency too high for stream load; would require significant infrastructure for concurrent complex queries |
| Streaming/real-time pipeline | GWI data arrives in waves, not streams; real-time processing doesn't match the data model |

---

## ADR-002: Narrative Generation — LLM Selection and Architecture

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Engineering Lead, ML Lead, Product Lead

### Context

Every insight in the stream requires a natural-language narrative: a headline, relevance explanation, and contextual framing. This narrative must be accurate, concise, and business-relevant. We need to decide how to generate these narratives at scale.

### Decision

**Use a managed LLM service (Anthropic Claude API) with structured prompting and a validation layer.**

- **Generation**: Each insight candidate from the batch pipeline is passed through a structured prompt template that includes: the statistical pattern (in structured data format), the user's context (category, audience, competitive set), and formatting/tone guidelines. The LLM generates the narrative components.

- **Validation**: A post-generation validation layer checks: statistical claims in the narrative against source data (automated), narrative length and format compliance (automated), and factual consistency scoring (model-based).

- **Caching**: Generated narratives are cached at the insight level. Personalization (the "why this matters to you" component) is generated at scoring time using lightweight template + LLM hybrid approach.

- **Fallback**: If LLM generation fails or validation rejects the output, a template-based fallback generates a simpler but guaranteed-accurate narrative.

### Rationale

- LLMs produce significantly more readable and business-relevant narratives than template-based approaches
- Managed service avoids the operational overhead of hosting and scaling inference infrastructure in v1
- The validation layer mitigates the primary risk (hallucinated statistics or misleading claims)
- Caching at the insight level means LLM cost scales with insight volume, not user volume
- Template fallback ensures reliability even during LLM service degradation

### Consequences

- Dependency on external LLM provider for a core product feature
- Cost per insight generation must be monitored and optimized
- Latency of LLM generation is acceptable in the batch pipeline but may constrain on-demand thread narratives
- Validation layer requires investment in automated statistical checking
- Narrative quality is bounded by prompt engineering effectiveness — requires ongoing refinement

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Template-only generation | Produces generic, robotic narratives that don't differentiate the product |
| Self-hosted open-source LLM | Operational overhead too high for v1; quality gap for nuanced business narratives |
| No narrative (data-only cards) | Defeats the core value proposition — users shouldn't need to interpret raw statistics |

---

## ADR-003: Personalization Architecture — User Context Model

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: ML Lead, Engineering Lead, Product Lead

### Context

The Insight Surface's core differentiator is personalization — surfacing what matters to each specific user. We need to decide how to model, store, and update user context.

### Decision

**Multi-signal context model with three tiers: explicit, inferred, and organizational.**

#### Model Structure

```
User Context Model
├── Explicit Context (user-configured)
│   ├── Brand / company
│   ├── Target audiences (saved segments)
│   ├── Competitive set
│   ├── Focus topics (manually tagged)
│   └── Relevance reactions (per-insight feedback)
│
├── Inferred Context (behavior-derived)
│   ├── Topic interest scores (from exploration patterns)
│   ├── Dimension preferences (which data cuts they explore most)
│   ├── Depth profile (surface scanner vs. deep diver)
│   ├── Temporal preferences (recency bias vs. trend preference)
│   └── Insight type preferences (anomalies vs. trends vs. correlations)
│
└── Organizational Context (team/account-level)
    ├── Account category and vertical
    ├── Team focus areas (admin-configured)
    ├── Shared canvas topics
    └── Aggregate team interest patterns
```

#### Storage

- Context models stored in a dedicated user profile service (key-value store optimized for fast reads)
- Explicit context updated synchronously on user action
- Inferred context updated in micro-batches (every 5 minutes during active session) and full recalculation nightly
- Organizational context updated on admin action and nightly batch

#### Scoring

- Relevance scoring is a weighted function across all three tiers
- Default weights: Explicit (0.5), Inferred (0.3), Organizational (0.2)
- Weights shift toward Inferred as the system accumulates more behavioral data
- A "diversity bonus" is applied to prevent filter bubbles — insights that are contextually relevant but topically novel receive a score boost

### Rationale

- Three-tier model ensures value from day one (organizational context) while improving over time (inferred context)
- Separation of explicit and inferred allows the system to learn without overriding user preferences
- Organizational tier enables team coherence without forcing uniformity
- Diversity bonus is essential to prevent the personalization trap where users only see reinforcing patterns

### Consequences

- Context model complexity requires careful schema design to remain performant
- The weighting function needs empirical tuning — initial weights are hypothesized, not validated
- Privacy implications of behavioral tracking must be clearly communicated to users
- Inferred context may develop biases based on early interactions — needs periodic decay/refresh mechanism
- Cross-device session stitching is required for accurate behavioral inference

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Explicit-only context | Cold start problem; requires too much user effort; doesn't learn or improve |
| Collaborative filtering (users like you also...) | GWI user base may be too small for reliable collaborative signals; risks surfacing competitor-relevant insights |
| Single flat profile | Doesn't capture the distinction between what users say they want and what they actually explore |

---

## ADR-004: Thread Exploration — Data Access Pattern

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Engineering Lead, Data Engineering Lead

### Context

Thread exploration requires the system to generate follow-up analyses on-demand as users drill deeper into insights. This requires fast, flexible access to the underlying GWI dataset. We need to decide the data access pattern for thread generation.

### Decision

**Pre-indexed analytical data store with a query generation layer.**

- **Analytical store**: Maintain a denormalized, pre-indexed analytical data store (columnar format, e.g., ClickHouse or BigQuery) optimized for the aggregation queries that thread exploration requires. This store is populated from the primary GWI data pipeline.

- **Query generation**: When a user expands a thread node, the system generates the appropriate analytical query based on: the parent insight's data context, the follow-up question type (breakdown, comparison, correlation, time series), and the user's context model (which dimensions to prioritize).

- **Pre-computation of likely paths**: For each insight in the global pool, the batch pipeline pre-computes the top 3 most likely follow-up analyses and caches the results. This covers the majority of thread explorations with cached responses.

- **Fallback to live query**: For follow-ups not covered by pre-computation, the system generates and executes a live query against the analytical store. Target: < 2 seconds for 95th percentile of live queries.

### Rationale

- Pre-computation of top follow-ups ensures sub-second response for the most common exploration paths
- Live query fallback ensures unlimited thread depth without constraining what users can explore
- Columnar analytical store is purpose-built for the aggregation-heavy query patterns thread exploration generates
- Query generation layer abstracts the complexity of translating "next logical question" into SQL/analytical queries

### Consequences

- Requires maintaining a separate analytical store synchronized with the primary data pipeline
- Pre-computation increases batch pipeline compute and storage costs
- Live query performance depends on analytical store capacity and query optimization
- Query generation layer is a complex component that must handle diverse follow-up types
- Data consistency between pre-computed results and live query results must be guaranteed

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Query primary data warehouse directly | Too slow for interactive exploration; competing with other workloads |
| Fully pre-computed thread trees | Combinatorial explosion makes full pre-computation infeasible beyond 2-3 levels |
| Client-side computation | Dataset too large; would expose raw data to the client |

---

## ADR-005: Canvas Architecture — Storage and Collaboration Model

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Engineering Lead, Frontend Lead, Product Lead

### Context

The Canvas is a persistent, collaborative workspace where users accumulate and synthesize insights. We need to decide how canvas state is stored, synchronized, and shared.

### Decision

**Document-based storage with operational transformation for real-time collaboration.**

- **Storage model**: Each canvas is a document containing an ordered list of items, each with: insight reference (pointer to the source insight in the global pool), spatial position (x, y coordinates on the canvas), user annotations (text, labels, color coding), group memberships (which cluster the item belongs to), and metadata (added by, added at, source thread path).

- **Persistence**: Canvas documents are stored in a document database (e.g., MongoDB or PostgreSQL JSONB) with per-canvas versioning.

- **Collaboration**: Real-time collaboration uses operational transformation (OT) or CRDT-based synchronization, similar to collaborative document editing. Changes are broadcast to all viewers of a shared canvas with < 500ms latency.

- **Permissions**: Canvas-level permissions: Owner (full control), Editor (add/remove/arrange items, annotate), Viewer (read-only). Inherited from GWI account roles by default, overridable per canvas.

- **Export pipeline**: Export triggers a rendering pipeline that transforms the canvas document into the requested format (PDF brief, PPTX, markdown, data package). Narrative summaries are generated via the LLM pipeline (see ADR-002) at export time.

### Rationale

- Document-based storage naturally represents the heterogeneous, hierarchical canvas structure
- OT/CRDT enables real-time collaboration without conflict resolution UX overhead
- Per-canvas versioning supports undo/redo and audit trail
- Permission model is simple enough for v1 while extensible for future needs
- Export-time narrative generation ensures summaries reflect the latest canvas state

### Consequences

- Real-time collaboration infrastructure is a significant engineering investment
- Canvas documents can grow large — need size limits or pagination for performance
- OT/CRDT implementation complexity, especially for spatial positioning conflicts
- Export pipeline must handle diverse output formats — maintenance burden
- Narrative generation at export time introduces latency — need async export with notification

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Relational storage with joins | Too rigid for the heterogeneous, evolving canvas schema |
| File-based storage (JSON on S3) | Doesn't support real-time collaboration efficiently |
| No real-time collaboration (save and refresh) | Significantly diminishes the team value proposition |

---

## ADR-006: Frontend Architecture — Application Shell and Rendering Strategy

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Frontend Lead, Engineering Lead

### Context

The Insight Surface UI consists of three distinct but interconnected views: the Insight Stream (feed), Thread Exploration (progressive disclosure tree), and Canvas (spatial workspace). We need a frontend architecture that supports all three with consistent performance.

### Decision

**Single-page application with view-based code splitting and a shared state layer.**

- **Framework**: React with TypeScript (aligns with existing GWI frontend stack)
- **State management**: A shared state layer (Zustand or similar) that maintains: current user context, active insight stream with pagination state, active thread exploration state, and canvas document state (with collaboration sync)
- **Rendering strategy**: Stream uses virtualized list rendering (only visible cards are in the DOM). Thread uses progressive rendering (nodes render on expansion). Canvas uses a 2D rendering engine (e.g., React Flow or custom canvas with HTML overlay).
- **Code splitting**: Each major view (Stream, Thread, Canvas) is a separately loaded module. Transitions between views use shared state to avoid data refetching.
- **Offline support**: Not required for v1. Stream data is not cached for offline access.

### Rationale

- React + TypeScript aligns with existing GWI engineering capabilities and hiring
- Virtualized rendering is essential for the potentially long insight stream
- Progressive thread rendering matches the UX model (users reveal depth on demand)
- 2D rendering engine for canvas provides the spatial manipulation capabilities required
- Shared state layer enables seamless transitions between views (e.g., saving from thread to canvas without losing context)

### Consequences

- Canvas rendering engine is the highest-complexity frontend component — may require specialized expertise
- Shared state layer must be carefully designed to avoid performance issues as state grows
- Three distinct rendering approaches in one app increases frontend complexity
- Testing strategy must cover the interactions between views, not just individual view behavior

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Server-rendered pages | Doesn't support the interactive, real-time nature of thread exploration and canvas manipulation |
| Micro-frontends per view | Over-engineering for v1; adds operational complexity without sufficient benefit at current scale |
| Native mobile app | Web-first aligns with GWI's current platform strategy; mobile can be a PWA wrapper in v1 |

---

## ADR-007: Insight Quality and Trust — Statistical Validation Framework

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Data Science Lead, Product Lead, Engineering Lead

### Context

User trust is the single most important factor in Insight Surface adoption. If users encounter inaccurate, misleading, or trivially obvious insights, they will disengage permanently. We need a rigorous quality framework.

### Decision

**Three-layer validation with automated checks, model-based scoring, and human review.**

#### Layer 1: Automated Statistical Validation

Every insight candidate is checked against:

- **Significance threshold**: Minimum sample size (configurable, default n ≥ 500) and statistical significance (p < 0.05 for claimed differences)
- **Effect size minimum**: Small but significant differences are filtered out — the pattern must be meaningful, not just statistically detectable
- **Recency check**: Data underpinning the insight must be from the most recent complete wave
- **Consistency check**: Claimed trends must be consistent across at least 2 data points (no single-wave anomalies presented as trends)
- **Narrative accuracy**: NLP-based check that statistical claims in the generated narrative match the underlying data (e.g., "23% increase" verified against actual data)

#### Layer 2: Quality Scoring Model

A trained model scores each insight on:

- **Novelty**: How surprising is this pattern relative to baseline expectations?
- **Actionability**: Does this pattern have clear business implications?
- **Clarity**: Is the narrative understandable to the target persona?
- **Robustness**: How sensitive is the pattern to small changes in parameters?

Insights must exceed a minimum composite quality score to enter the global pool.

#### Layer 3: Human Review (Beta Period)

During closed and open beta:

- Product and data science team reviews a sample of surfaced insights daily
- User-flagged insights are reviewed within 24 hours
- Systematic error patterns trigger pipeline adjustments
- Review cadence reduces as automated layers prove reliable

### Rationale

- Automated validation catches the most dangerous errors (incorrect statistics) at scale
- Quality scoring prevents the "technically correct but useless" problem
- Human review during beta builds confidence in the automated layers and catches novel failure modes
- Three layers provide defense in depth — no single point of failure for quality

### Consequences

- Quality thresholds will filter out a significant portion of insight candidates — the global pool will be smaller but higher quality
- Overly aggressive thresholds risk an empty stream for niche contexts — need per-category threshold tuning
- Quality scoring model requires training data — bootstrapped from internal expert ratings
- Human review is resource-intensive and must be phased out as automation matures
- False negative rate (good insights filtered out) is harder to measure than false positive rate (bad insights let through)

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Automated validation only | Insufficient for catching subtle quality issues like misleading framing |
| Human review only | Doesn't scale; creates bottleneck for pipeline throughput |
| User feedback only | Cold start — need baseline quality before users will engage enough to provide feedback |

---

## ADR-008: Cold Start Strategy — Day-One Value Delivery

**Status**: Proposed
**Date**: 2026-01-31
**Deciders**: Product Lead, Data Science Lead, Design Lead

### Context

New users have no behavioral history for the personalization engine. The system must deliver compelling, relevant insights from the very first interaction.

### Decision

**Layered cold start with progressive personalization.**

#### Tier 1: Account-Level Context (Immediate)

When a new user logs in, the system knows their account's brand, category, and competitive set. This provides enough context to:

- Surface category-level trending insights
- Show competitive benchmark patterns
- Present audience-level shifts relevant to the brand's category

#### Tier 2: Role-Based Templates (Within 10 seconds)

Based on the user's role (inferred from account permissions or asked during lightweight onboarding):

- **Strategist**: Prioritize trend insights with strategic implications
- **Analyst**: Prioritize anomaly detection and cross-dimensional patterns
- **Executive**: Prioritize headline-level competitive and market insights

#### Tier 3: Rapid Preference Capture (Within first session)

- After 3 insight interactions, show a lightweight preference prompt: "You seem interested in [topic]. Want to see more like this?"
- "Quick focus" selector: Present 5-8 common focus areas for the user's category; user selects 1-3
- Every interaction refines the model — within one session, the stream noticeably improves

#### Tier 4: Full Personalization (After 3-5 sessions)

- Inferred context model has sufficient signal to drive personalization
- Explicit context supplements inferred model
- System transitions from template-driven to model-driven recommendations

### Rationale

- Account-level context provides a strong baseline that competitors without GWI data can't match
- Role-based templates address the different needs of each persona from minute one
- Rapid preference capture gives users agency and visible proof that the system is learning
- Progressive approach avoids overwhelming new users with configuration while building toward full personalization

### Consequences

- Category-level insight library must be pre-built and maintained for all GWI categories
- Role inference from permissions may be inaccurate — fallback to asking is acceptable
- "Quick focus" selector must be dynamically generated per category — maintenance cost
- Transition from template-driven to model-driven must be smooth — no jarring shifts in stream character
- Accounts in niche categories may have thinner category-level insight libraries

### Alternatives Considered

| Alternative | Why Rejected |
|-------------|-------------|
| Extensive onboarding questionnaire | High friction; most users won't complete it; delays time to value |
| Generic insights for all new users | Too impersonal; fails to demonstrate the product's personalization promise |
| Wait for behavioral data before serving personalized insights | Unacceptable cold start experience; users won't return if first session is poor |
