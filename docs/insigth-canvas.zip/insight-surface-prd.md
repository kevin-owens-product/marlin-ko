# Product Requirements Document: Insight Surface

**Product**: Insight Surface
**Owner**: Kevin (CPO, GWI)
**Status**: Draft
**Version**: 0.1
**Last Updated**: 2026-01-31

---

## 1. Executive Summary

Insight Surface is a new product experience that replaces GWI's traditional cross-tab and dashboard interfaces with an AI-driven, discovery-first intelligence layer. Instead of requiring users to formulate queries and manually explore data, Insight Surface continuously analyzes the GWI dataset and proactively surfaces relevant patterns, trends, and anomalies personalized to each user's context.

The product shifts the user's role from **query constructor** to **relevance judge**, dramatically lowering the expertise barrier while increasing the depth and speed of insight discovery.

---

## 2. Problem Statement

### 2.1 Current State

GWI clients access consumer intelligence primarily through cross-tabulations and pre-built dashboards. This model requires users to:

- Know which variables to query before they begin
- Understand the GWI data model, variable taxonomy, and segment definitions
- Manually iterate through hypotheses by adjusting filters and dimensions
- Interpret raw statistical outputs and translate them into business meaning
- Export and reformat data for stakeholder consumption

### 2.2 Pain Points

| Pain Point | Impact | Evidence |
|------------|--------|----------|
| **Blank canvas paralysis** | Users open the platform and don't know where to start, leading to underutilization | Low session frequency among non-analyst users; high support ticket volume for "how do I..." questions |
| **Unknown unknowns** | Users only discover patterns they already suspect, missing the highest-value insights | Qualitative feedback from customer success; comparison of user-explored vs. available data dimensions |
| **Expertise bottleneck** | Value extraction concentrates in a small number of power users per account | Usage analytics showing Pareto distribution of engagement within accounts |
| **Time to insight** | Manual cross-tab iteration is slow, creating lag between question and answer | Average session-to-insight time metrics; customer feedback on speed |
| **Insight fragmentation** | Discoveries are scattered across sessions with no cumulative knowledge layer | No persistent workspace; insights lost between sessions |

### 2.3 Desired Outcome

A product where:

- New users get value within their first 60 seconds without any training
- The system finds patterns the user wouldn't have thought to look for
- Insight quality improves with continued usage through personalization
- Discoveries accumulate into a persistent, shareable knowledge asset
- The expertise required shifts from "data querying" to "pattern recognition"

---

## 3. Goals & Success Metrics

### 3.1 Business Goals

| Goal | Metric | Target |
|------|--------|--------|
| Increase platform engagement | Weekly active users (WAU) | +40% within 6 months of launch |
| Expand user base within accounts | Unique users per account | +60% (from ~3 to ~5 avg) |
| Reduce time to first value | Time from login to first meaningful interaction | < 30 seconds |
| Increase retention | Net revenue retention (NRR) | +5 percentage points |
| Create switching costs | Personalization depth score (proprietary metric) | 80% of active users exceed threshold within 90 days |

### 3.2 Product Goals

| Goal | Metric | Target |
|------|--------|--------|
| Insight relevance | User relevance rating on surfaced insights | > 70% rated "relevant" or "very relevant" |
| Discovery rate | % of user-explored insights that were proactively surfaced vs. manually found | > 60% surfaced by system |
| Thread depth | Average exploration depth per session | > 3 levels |
| Synthesis adoption | % of active users creating canvas items | > 40% within 90 days |
| Personalization improvement | Relevance score improvement over time per user | +15% month-over-month for first 6 months |

---

## 4. User Personas

### 4.1 Primary: The Brand Strategist

**Role**: Brand Manager, Senior Strategist, Planning Director
**Company**: Brand-side marketing team or agency
**GWI Usage**: Weekly, focused on audience understanding and trend identification
**Current pain**: Knows what they want to learn but struggles to translate business questions into data queries. Relies on internal analysts or customer success to extract insights.
**Insight Surface value**: Sees relevant patterns without needing to query. Pulls threads to build strategic narratives. Shares discoveries directly with stakeholders.

### 4.2 Secondary: The Research Analyst

**Role**: Consumer Insights Analyst, Research Manager
**Company**: Brand-side insights team or research agency
**GWI Usage**: Daily, deep cross-tab analysis and data export
**Current pain**: Spends majority of time on data extraction mechanics rather than analysis. Misses cross-dimensional patterns due to query-by-query workflow.
**Insight Surface value**: System pre-computes the patterns they'd otherwise spend hours finding. Thread exploration accelerates hypothesis testing. Canvas replaces manual deck-building.

### 4.3 Tertiary: The Executive Consumer

**Role**: CMO, VP Marketing, VP Strategy
**Company**: Brand-side leadership
**GWI Usage**: Monthly or less, views shared reports
**Current pain**: Only sees GWI data filtered through their team's interpretations. No direct connection to the intelligence layer.
**Insight Surface value**: Opens the product and immediately sees what matters to their business without any learning curve. First direct engagement with GWI data.

---

## 5. Product Scope

### 5.1 In Scope (v1)

#### 5.1.1 Context Engine

The foundational layer that understands who the user is and what matters to them.

**Requirements**:

- **CTX-001**: System shall infer user context from account metadata (brand, category, competitive set, target audiences) without requiring manual configuration
- **CTX-002**: System shall incorporate usage history (previously explored dimensions, saved items, shared insights) to build a user interest model
- **CTX-003**: System shall support explicit context overrides where users can specify focus areas, brands, audiences, or themes
- **CTX-004**: Context model shall update in real-time as user interacts with the product within a session
- **CTX-005**: System shall maintain separate context models for individual users and team-level aggregates
- **CTX-006**: Context model shall be inspectable by the user ("Here's what I think matters to you") with ability to correct

#### 5.1.2 Insight Generation Pipeline

The AI layer that continuously scans the GWI dataset and produces insight candidates.

**Requirements**:

- **IGP-001**: Pipeline shall run anomaly detection across all data dimensions relevant to the user's context, identifying statistically significant deviations from baseline
- **IGP-002**: Pipeline shall perform trend analysis with directional indicators (accelerating, decelerating, stable, emerging, declining)
- **IGP-003**: Pipeline shall identify cross-dimensional correlations that connect disparate data points (e.g., media consumption patterns correlated with purchase intent shifts)
- **IGP-004**: Pipeline shall detect competitive divergences — patterns where the user's target audience behaves differently from competitors' audiences
- **IGP-005**: Pipeline shall generate natural-language narrative summaries for each insight, translating statistical patterns into business-relevant language
- **IGP-006**: Each generated insight shall include: narrative headline, contextual relevance explanation, statistical confidence metrics (sample size, significance level, trend direction), and source data references
- **IGP-007**: Pipeline shall assign a relevance score to each insight based on the user's context model
- **IGP-008**: Pipeline shall deduplicate and cluster related insights to prevent redundancy in the stream
- **IGP-009**: Pipeline refresh cadence shall be configurable but default to daily for trend insights and real-time for anomaly detection on new data waves

#### 5.1.3 Insight Stream

The primary user-facing interface — a personalized feed of discovery cards.

**Requirements**:

- **STR-001**: Stream shall present insight cards in descending order of relevance score, with recency as a secondary sort
- **STR-002**: Each insight card shall display: narrative headline, relevance context ("Why this matters to you"), confidence indicators, and action hooks
- **STR-003**: Stream shall support category-based filtering (e.g., "Trends", "Anomalies", "Competitive", "Audience shifts")
- **STR-004**: Stream shall support temporal filtering (e.g., "This week", "This month", "Since last visit")
- **STR-005**: Stream shall indicate new insights since the user's last session
- **STR-006**: Users shall be able to react to insight cards: "Relevant", "Not relevant", "Surprising", "Already knew this"
- **STR-007**: User reactions shall feed back into the context engine to improve future relevance scoring
- **STR-008**: Stream shall be the default landing experience when users open the product
- **STR-009**: Stream shall support infinite scroll with progressive loading
- **STR-010**: Stream shall render within 2 seconds of page load with at least 5 insight cards visible

#### 5.1.4 Thread Exploration

The interactive deep-dive experience triggered from any insight card.

**Requirements**:

- **THR-001**: Clicking an insight card shall open a thread view that expands the insight with pre-computed follow-up analyses
- **THR-002**: System shall generate 3-5 "next logical questions" for each insight, presented as expandable thread nodes
- **THR-003**: Thread nodes shall include: breakdown by key dimensions (market, demographic, time period), comparison views (vs. competitors, vs. general population, vs. previous period), and related pattern connections
- **THR-004**: Users shall be able to branch at any thread node, creating divergent exploration paths
- **THR-005**: Thread exploration history shall be preserved within the session and accessible via a breadcrumb trail
- **THR-006**: At any point in a thread, users shall be able to save the current insight + context to their canvas
- **THR-007**: System shall suggest "You might also be interested in..." connections to other insight cards from the stream
- **THR-008**: Thread depth shall be unlimited, with system-generated follow-ups at each level
- **THR-009**: Thread nodes shall load within 1 second of user interaction (pre-computation required)
- **THR-010**: Users shall be able to share a specific thread state via link with team members

#### 5.1.5 Canvas

The persistent synthesis workspace where discoveries accumulate.

**Requirements**:

- **CNV-001**: Canvas shall provide a spatial workspace where users can arrange saved insights
- **CNV-002**: System shall auto-suggest connections between canvas items based on data relationships
- **CNV-003**: Canvas shall support manual grouping, labeling, and annotation of insight clusters
- **CNV-004**: System shall generate narrative summaries of canvas clusters on demand ("Based on these 7 insights, here's the story...")
- **CNV-005**: Canvas shall be persistent across sessions
- **CNV-006**: Canvas shall support sharing with team members with view/edit permissions
- **CNV-007**: Canvas shall support export as: structured brief (markdown/PDF), presentation-ready format, and raw data package
- **CNV-008**: Users shall be able to create multiple named canvases (e.g., per project, per brief, per quarter)
- **CNV-009**: Canvas shall display a timeline view showing when insights were added and how the narrative evolved
- **CNV-010**: Team members shall be able to contribute insights to shared canvases from their own streams

#### 5.1.6 Feedback & Personalization

The learning loop that improves the system over time.

**Requirements**:

- **FBK-001**: System shall track implicit signals: dwell time on insight cards, thread exploration depth, canvas save actions, share actions
- **FBK-002**: System shall support explicit feedback: relevance reactions on insight cards, topic interest toggles, "show me more/less like this" controls
- **FBK-003**: Personalization model shall update within-session for immediate feedback and batch-update overnight for deeper model refinement
- **FBK-004**: Users shall be able to view a summary of their personalization profile ("Topics you care about", "Patterns you've explored")
- **FBK-005**: Users shall be able to reset or adjust their personalization profile
- **FBK-006**: System shall provide a "personalization score" indicating how well-calibrated the model is for each user
- **FBK-007**: Team admins shall be able to set organizational context that influences all team members' streams (e.g., "This quarter we're focused on sustainability")

### 5.2 Out of Scope (v1)

- **Direct data query interface** — Power users who need raw cross-tab access will continue using the existing product. Integration between Insight Surface and the existing query tool is planned for v2.
- **Custom data upload** — Insights are generated from the GWI dataset only. Client first-party data integration is a future consideration.
- **Automated actions** — v1 is insight discovery and synthesis. Automated brief generation, campaign recommendations, and workflow triggers are v2+.
- **Multi-language insight generation** — v1 generates English-language narratives only. Localization is planned for v2.
- **API access** — v1 is a product experience only. Programmatic access to the insight stream is v2+.

---

## 6. User Flows

### 6.1 First-Time User (Cold Start)

```
1. User logs in → System detects new user
2. Brief onboarding overlay (< 30 seconds):
   - "Welcome to Insight Surface. We've already started finding patterns in your data."
   - Auto-detected context displayed: "You work at [Brand], focused on [Category]"
   - Optional: "Anything specific you're exploring right now?" (free text, skippable)
3. Insight Stream loads with category-level trending insights
   - Top card: "Here's what's changing in [Category] right now"
   - Subsequent cards: audience shifts, competitive movements, emerging trends
4. User interacts → personalization begins immediately
```

### 6.2 Returning User (Personalized)

```
1. User logs in → Stream loads with personalized insights
2. Badge: "12 new insights since your last visit"
3. Top section: "Based on your recent exploration of [Topic], here's what's new..."
4. User pulls thread on an insight → explores 3 levels deep
5. Saves key finding to canvas → continues browsing stream
6. Opens canvas → reviews accumulated insights → requests narrative summary
7. Exports brief → shares with team
```

### 6.3 Team Collaboration

```
1. User A discovers insight → saves to shared canvas "Q1 Strategy"
2. User B opens shared canvas → sees User A's contribution
3. User B's stream now surfaces related insights (influenced by team canvas)
4. User B adds complementary insight to canvas
5. Team lead opens canvas → requests auto-generated narrative
6. System produces: "Your team has identified three converging trends..."
7. Team lead exports as presentation brief
```

---

## 7. Non-Functional Requirements

### 7.1 Performance

| Requirement | Specification |
|-------------|---------------|
| Stream load time | < 2 seconds to first meaningful content |
| Thread node expansion | < 1 second per node |
| Canvas load time | < 3 seconds for canvases with up to 100 items |
| Insight pipeline latency | New data wave → insights available within 4 hours |
| Concurrent users | Support 10,000 concurrent sessions |

### 7.2 Reliability

| Requirement | Specification |
|-------------|---------------|
| Uptime | 99.9% availability |
| Data consistency | Insights reflect the most recent complete data wave |
| Failover | Graceful degradation — if AI pipeline is delayed, serve cached insights with "last updated" indicator |

### 7.3 Security & Privacy

| Requirement | Specification |
|-------------|---------------|
| Data isolation | Account-level data isolation; no cross-account data leakage in insight generation |
| User privacy | Personalization data is per-user and not visible to other users (including admins) without explicit sharing |
| Compliance | GDPR-compliant data handling for all user interaction data |
| Access control | Role-based access aligned with existing GWI account permissions |

### 7.4 Scalability

| Requirement | Specification |
|-------------|---------------|
| Insight generation | Pipeline shall scale horizontally to support full GWI client base |
| Personalization models | Per-user models shall be stored and computed efficiently for 100,000+ users |
| Canvas storage | No hard limit on canvas items; performance targets met up to 500 items per canvas |

---

## 8. Dependencies

| Dependency | Owner | Risk |
|------------|-------|------|
| GWI data pipeline (structured, queryable dataset) | Data Engineering | Low — existing infrastructure |
| LLM inference infrastructure for narrative generation | Platform Engineering | Medium — requires new infrastructure or managed service |
| Anomaly detection / trend analysis models | Data Science | Medium — new capability, requires R&D |
| Personalization / recommendation engine | ML Engineering | Medium — new capability |
| Real-time event processing for implicit feedback | Platform Engineering | Low — standard infrastructure |
| Frontend framework supporting stream + thread + canvas UX | Frontend Engineering | Medium — significant new UI paradigm |

---

## 9. Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Insight quality too low at launch → users lose trust | Medium | High | Extensive pre-launch quality evaluation with real accounts; conservative relevance thresholds; human-in-the-loop review for first 90 days |
| Cold start experience feels generic → new users don't return | Medium | Medium | Invest heavily in category-level insight library; fast onboarding context capture; "wow moment" within first 3 insights |
| Personalization creates filter bubble → users miss important patterns | Low | Medium | "Wildcard" insights injected at regular intervals; "Outside your usual" section in stream; team-level context breaks individual bubbles |
| Power users feel constrained → resistance from analyst persona | Medium | Medium | Position as complementary to (not replacement of) existing tools in v1; provide "View source data" escape hatch on every insight |
| Pipeline compute costs exceed projections | Medium | Medium | Tiered computation — heavy analysis for high-engagement users, lighter for low-engagement; caching and pre-computation strategies |
| Narrative generation produces inaccurate or misleading summaries | Medium | High | Every narrative linked to source data; confidence indicators on all claims; user flagging mechanism; automated accuracy checks against underlying statistics |

---

## 10. Rollout Strategy

### Phase 1: Closed Beta (8 weeks)

- 10-15 hand-selected accounts representing all three personas
- Daily insight quality review by product team
- Weekly user interviews
- Rapid iteration on relevance scoring and narrative quality
- Success gate: > 60% relevance rating, > 70% weekly return rate

### Phase 2: Open Beta (8 weeks)

- Available to all accounts, opt-in
- Focus on personalization effectiveness and scale testing
- Introduce canvas and collaboration features
- Success gate: > 50% of opt-in users active weekly, NPS > 40

### Phase 3: General Availability

- Default experience for new users
- Existing users prompted to try with guided transition
- Existing cross-tab and dashboard tools remain accessible
- Success gate: Engagement metrics meeting targets in Section 3

---

## 11. Open Questions

1. **Data freshness expectations** — How do we message insight staleness when data waves are monthly but users expect daily freshness?
2. **Multi-brand accounts** — How do agencies with many brand clients manage context switching in their stream?
3. **Insight attribution** — When a team member shares an insight externally, how is it attributed and branded?
4. **Competitive intelligence sensitivity** — Are there insights we shouldn't surface (e.g., showing a brand that their competitor is outperforming them on every dimension)?
5. **Integration with existing workflows** — What's the migration path for users who have built processes around cross-tabs and dashboards?
