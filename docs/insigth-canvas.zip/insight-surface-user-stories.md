# User Stories: Insight Surface

---

## Legend

**Priority**: P0 (Must have for launch), P1 (Should have for launch), P2 (Nice to have / fast follow)
**Persona**: BS (Brand Strategist), RA (Research Analyst), EC (Executive Consumer), ALL (All personas)
**Epic**: The parent capability group

---

## Epic 1: Context Engine

### US-1.1: Automatic Context Detection

**As a** new user logging in for the first time,
**I want** the system to automatically detect my brand, category, and competitive set from my account data,
**So that** I receive relevant insights immediately without manual configuration.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user logs in with a GWI account, when the Insight Surface loads, then the system displays the detected context (brand, category, competitive set) in a visible but non-intrusive element
- Given the system detects context, when it is incorrect, then the user can correct it inline with immediate effect on the stream
- Given a user account has no brand association (e.g., agency account), then the system prompts the user to select a primary brand focus with a searchable selector
- Context detection completes within 1 second of authentication

---

### US-1.2: Explicit Context Configuration

**As a** user who wants to refine what I see,
**I want** to manually configure my focus areas, target audiences, and competitive set,
**So that** the system surfaces insights aligned with my current priorities.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user opens context settings, when they add/remove brands from their competitive set, then the stream updates within the same session to reflect the change
- Given a user sets target audiences using GWI segment definitions, when insights are generated, then audience-specific patterns are prioritized
- Given a user adds a focus topic (free text or tag-based), when the topic matches data dimensions, then related insights are boosted in relevance scoring
- Users can configure up to 10 competitors, 5 target audiences, and 20 focus topics
- All explicit context changes are saved immediately and persist across sessions

---

### US-1.3: Context Transparency

**As a** user who wants to understand why I see certain insights,
**I want** to view what the system believes about my interests and priorities,
**So that** I can verify the system's understanding and correct it if needed.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given a user opens their personalization profile, then they see: explicit context (brand, competitors, audiences, topics), inferred interests (ranked list of topics the system believes they care about, with confidence levels), and organizational context (team focus areas)
- Given a user sees an inferred interest they disagree with, when they dismiss it, then it is removed from the model and the stream updates accordingly
- The personalization profile is accessible from the main navigation in ≤ 2 clicks

---

### US-1.4: Organizational Context Setting

**As a** team admin,
**I want** to set team-level focus areas that influence all team members' insight streams,
**So that** the entire team receives insights aligned with our current strategic priorities.

**Priority**: P1
**Persona**: BS (team leads), RA (team leads)

**Acceptance Criteria**:

- Given an admin sets a team focus area (e.g., "Sustainability in Gen Z"), when team members open their streams, then insights matching the team focus are boosted in relevance
- Given an admin updates team focus areas, when team members next load the stream, then the change is reflected
- Team focus areas are additive to individual personalization — they do not override personal context
- Admins can set up to 10 team focus areas
- Non-admin users can see the team focus areas but cannot modify them

---

## Epic 2: Insight Stream

### US-2.1: Personalized Insight Feed

**As a** returning user,
**I want** to see a feed of insight cards ranked by relevance to my context when I open the product,
**So that** I immediately see what matters most without searching or querying.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user opens Insight Surface, when the stream loads, then at least 5 insight cards are visible within 2 seconds
- Each insight card displays: narrative headline, "Why this matters to you" context, confidence indicator (sample size and significance), and trend direction
- Cards are ranked by relevance score (descending), with recency as tiebreaker
- The stream supports infinite scroll with progressive loading (next batch loads when user scrolls to 80% of current content)
- No two consecutive cards in the stream cover the same topic cluster

---

### US-2.2: New Insight Indicators

**As a** returning user,
**I want** to see which insights are new since my last visit,
**So that** I can focus on what's changed rather than re-reading old discoveries.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user returns after a previous session, when the stream loads, then a badge indicates the count of new insights since last visit (e.g., "14 new insights")
- New insights are visually distinguished from previously seen insights (e.g., subtle highlight or "New" badge)
- A "Jump to new" action scrolls the user to the first new insight
- "New" status persists until the user has scrolled past the card or interacted with it

---

### US-2.3: Stream Filtering

**As a** user looking for a specific type of insight,
**I want** to filter my stream by insight category and time period,
**So that** I can focus on the patterns most relevant to my current task.

**Priority**: P1
**Persona**: BS, RA

**Acceptance Criteria**:

- Given filter options are available, when a user selects a category filter (e.g., "Trends", "Anomalies", "Competitive", "Audience Shifts"), then only matching insights are shown
- Given a user selects a time filter (e.g., "This week", "This month", "This quarter"), then only insights based on data from that period are shown
- Filters can be combined (e.g., "Competitive" + "This month")
- Active filters are clearly displayed and easily removable
- Filtering is client-side for instant response (no server round-trip)
- Default state: no filters applied

---

### US-2.4: Insight Reactions

**As a** user evaluating an insight,
**I want** to react to insight cards to tell the system what's relevant to me,
**So that** future insights are better tailored to my needs.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given an insight card is displayed, when the user hovers or taps, then reaction options appear: "Relevant", "Not relevant", "Surprising", "Already knew this"
- Given a user reacts, then the reaction is recorded and confirmation is shown (subtle animation, no modal)
- Given a user marks an insight as "Not relevant", then similar insights are deprioritized in future sessions
- Given a user marks an insight as "Relevant" or "Surprising", then similar insights are boosted
- Reactions are optional — the system also learns from implicit signals (dwell time, thread entry, saves)
- A user can change their reaction at any time

---

### US-2.5: Cold Start Stream

**As a** first-time user with no interaction history,
**I want** to see valuable insights immediately upon first login,
**So that** I understand the product's value within my first 60 seconds.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a new user logs in, when the stream loads, then it displays category-level trending insights relevant to their account's brand/category
- The first card in the stream provides a "welcome" context: "Here's what's happening in [Category] right now"
- At least 10 insight cards are available for any GWI-supported category
- Within the first 3 interactions, the system prompts a lightweight preference capture ("Interested in [topic]? See more like this")
- Cold start insights have a minimum quality score of 80/100 (curated)

---

## Epic 3: Thread Exploration

### US-3.1: Thread Entry

**As a** user who finds an interesting insight,
**I want** to click into it and see deeper analysis automatically generated,
**So that** I can explore the pattern without constructing manual queries.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user clicks an insight card, when the thread view opens, then 3-5 pre-computed follow-up analyses are displayed as expandable nodes
- Follow-up nodes include: breakdown by key demographic/market dimensions, time-series view (how the pattern evolved), comparison view (vs. competitors or general population)
- Each follow-up node has a clear label describing the analysis (e.g., "Breakdown by age group", "How this compares to [Competitor]")
- Thread view loads within 1 second for pre-computed follow-ups
- The parent insight remains visible as context at the top of the thread

---

### US-3.2: Thread Branching

**As a** user exploring a thread,
**I want** to expand any follow-up node and see further analysis cascade,
**So that** I can follow my curiosity as deep as needed.

**Priority**: P0
**Persona**: BS, RA

**Acceptance Criteria**:

- Given a user expands a follow-up node, when the node opens, then 2-4 additional follow-up nodes appear beneath it
- Users can expand multiple nodes at different levels simultaneously
- A breadcrumb trail shows the current exploration path
- Thread depth is unlimited — the system generates follow-ups at each level
- For on-demand follow-ups (not pre-computed), loading indicator is shown and result appears within 3 seconds
- Users can collapse previously expanded nodes to reduce visual complexity

---

### US-3.3: Thread Suggestions

**As a** user exploring a specific pattern,
**I want** the system to suggest connections to other insights I might not have considered,
**So that** I discover non-obvious relationships across different data dimensions.

**Priority**: P1
**Persona**: BS, RA

**Acceptance Criteria**:

- Given a user is 2+ levels deep in a thread, when a related pattern exists in the insight pool, then a "Related insight" suggestion appears in the sidebar
- Suggestions are contextually relevant to the current thread path, not random
- Each suggestion includes a brief explanation of the connection (e.g., "Users interested in [current topic] also show unusual patterns in [related topic]")
- Clicking a suggestion opens it as a branching thread, preserving the current exploration state
- Maximum 3 suggestions visible at any point to avoid overwhelming the user

---

### US-3.4: Save to Canvas from Thread

**As a** user who has found a valuable insight within a thread,
**I want** to save the current insight + its exploration context to my canvas,
**So that** I can accumulate discoveries for later synthesis.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a user is viewing any node in a thread, when they click "Save to Canvas", then the insight (including the specific thread path that led to it) is added to their active canvas
- If the user has multiple canvases, a selector appears to choose the destination
- The saved item retains the full thread context (parent insight → exploration path → current node)
- Confirmation is shown without leaving the thread view
- Saved items appear on the canvas within 2 seconds

---

### US-3.5: Share Thread State

**As a** user who wants to share a specific discovery with a colleague,
**I want** to share the current thread state via a link,
**So that** my colleague sees exactly what I'm seeing without recreating the exploration.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given a user clicks "Share" on any thread node, then a shareable link is generated
- The link opens the thread at the exact same state (same expansions, same depth)
- The recipient must have a GWI account with appropriate permissions to view
- If the recipient doesn't have access, they see a message explaining how to request access
- Shared links persist for at least 90 days

---

## Epic 4: Canvas

### US-4.1: Canvas Creation and Management

**As a** user building strategic understanding over time,
**I want** to create named canvases and organize my saved insights spatially,
**So that** I can build narratives and see connections across discoveries.

**Priority**: P0
**Persona**: BS, RA

**Acceptance Criteria**:

- Given a user opens the Canvas view, when they click "New Canvas", then a new canvas is created with a name prompt
- Users can rename canvases at any time
- Users can create up to 50 canvases
- Saved insights appear as cards on the canvas that can be dragged and positioned freely
- Canvas state (positions, groups, annotations) auto-saves on every change
- Canvas loads within 3 seconds for up to 100 items

---

### US-4.2: Insight Clustering and Annotation

**As a** user synthesizing multiple insights,
**I want** to group related insights together and add my own notes,
**So that** I can build a structured narrative from scattered discoveries.

**Priority**: P0
**Persona**: BS, RA

**Acceptance Criteria**:

- Given insights are on a canvas, when a user selects multiple items, then they can create a named group (visual container)
- Groups can be labeled with a custom title and color
- Users can add free-text annotations to individual insights or groups
- Items can belong to only one group at a time but can be moved between groups
- Groups can be collapsed to save space and expanded to show detail

---

### US-4.3: AI-Suggested Connections

**As a** user with multiple insights on my canvas,
**I want** the system to suggest connections between items I might not see,
**So that** I discover non-obvious relationships and build richer understanding.

**Priority**: P1
**Persona**: BS, RA

**Acceptance Criteria**:

- Given a canvas has 5+ items, when the user triggers "Find connections" (or automatically after a new item is added), then the system analyzes the underlying data of all canvas items and suggests relationships
- Suggestions appear as dotted lines between items with a tooltip explaining the connection
- Users can accept (making the line solid), dismiss, or ignore suggestions
- Maximum 5 suggestions at a time to avoid visual clutter
- Suggestions refresh as items are added or removed

---

### US-4.4: Narrative Summary Generation

**As a** user who has assembled insights on a canvas,
**I want** to generate a written narrative summary of my canvas,
**So that** I can quickly communicate findings to stakeholders without writing from scratch.

**Priority**: P1
**Persona**: BS, EC

**Acceptance Criteria**:

- Given a canvas has 3+ items, when the user clicks "Generate Summary", then an AI-generated narrative is produced within 15 seconds
- The narrative covers: key themes identified across canvas items, supporting data points from each insight, strategic implications and potential actions, and areas requiring further investigation
- The narrative is generated in professional business language appropriate for stakeholder communication
- Users can regenerate with different emphasis (e.g., "Focus on competitive implications", "Make it shorter")
- The narrative is editable after generation
- Generated narrative can be copied or exported directly

---

### US-4.5: Canvas Sharing and Collaboration

**As a** team member working on a shared strategic initiative,
**I want** to share my canvas with colleagues who can view and contribute,
**So that** we build collective intelligence as a team.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given a user owns a canvas, when they click "Share", then they can invite team members by email or GWI username
- Share permissions: View (read-only), Edit (add/remove/arrange items, annotate), Owner (full control including delete and permission changes)
- Given multiple users have edit access, when one user makes a change, then all other active viewers see the change within 1 second
- Shared canvases appear in each team member's canvas list with a "Shared" indicator
- Activity log shows who added/modified items and when

---

### US-4.6: Canvas Export

**As a** user who needs to present findings to stakeholders,
**I want** to export my canvas as a formatted document or presentation,
**So that** I can share insights through existing communication channels.

**Priority**: P1
**Persona**: BS, RA

**Acceptance Criteria**:

- Given a canvas has content, when the user clicks "Export", then format options are presented: PDF brief, PowerPoint presentation, Markdown document, and CSV data package
- PDF and PPTX exports include: auto-generated title page, grouped insights with visualizations, narrative summary (if generated), and source data citations
- Export generation completes within 30 seconds and the user is notified when ready
- Export files include GWI branding and appropriate data citations
- Users can export the full canvas or selected groups

---

## Epic 5: Feedback & Personalization

### US-5.1: Implicit Signal Tracking

**As** the Insight Surface system,
**I want** to capture implicit behavioral signals from user interactions,
**So that** I can improve personalization without requiring explicit user effort.

**Priority**: P0
**Persona**: System (internal)

**Acceptance Criteria**:

- Given a user views an insight card for > 3 seconds, then a "dwell" event is recorded with duration
- Given a user enters a thread from an insight card, then a "thread_entry" event is recorded with the source insight ID
- Given a user reaches thread depth ≥ 3, then a "deep_exploration" event is recorded with the topic dimension
- Given a user saves an insight to canvas, then a "canvas_save" event is recorded as a high-value signal
- Given a user shares an insight or thread, then a "share" event is recorded as a high-value signal
- All events are timestamped and associated with the user's context model
- Events are processed in micro-batches (every 5 minutes during active sessions)
- Event capture adds < 50ms latency to any user interaction

---

### US-5.2: Explicit Feedback Controls

**As a** user who wants to actively train the system,
**I want** fine-grained controls to tell the system what I do and don't want to see,
**So that** my stream quickly converges on what's most relevant.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given a user is viewing an insight card, when they select "More like this", then similar insights are boosted in future sessions
- Given a user is viewing an insight card, when they select "Less like this", then similar insights are deprioritized
- Given a user opens personalization settings, then they see topic-level toggles (e.g., "Social media trends: High interest / Neutral / Low interest")
- Changes to explicit controls take effect within the current session
- Users can reset all explicit feedback to start fresh

---

### US-5.3: Personalization Effectiveness Indicator

**As a** user who wants to know if the system is learning,
**I want** to see an indicator of how well-calibrated my personalization is,
**So that** I know the system is improving and feel motivated to continue interacting.

**Priority**: P2
**Persona**: ALL

**Acceptance Criteria**:

- Given a user opens their personalization profile, then a "calibration score" is displayed (e.g., "Your Insight Surface is 72% calibrated")
- The score increases as the system accumulates more behavioral data and the user provides explicit feedback
- A brief explanation accompanies the score: "Based on X interactions over Y sessions. The more you explore, the better your insights get."
- The score is updated daily
- New users start at a baseline score that reflects account-level context quality

---

### US-5.4: Diversity Injection

**As a** user who wants to avoid a filter bubble,
**I want** the system to occasionally show me insights outside my usual areas,
**So that** I don't miss important patterns I wouldn't have thought to look for.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given a personalized stream is loaded, then at least 1 in every 10 insights is a "wildcard" — relevant to the user's broad context but outside their typical exploration areas
- Wildcard insights are subtly labeled (e.g., "Outside your usual") to set expectations
- If a user engages with a wildcard insight (thread entry or positive reaction), then the topic area is incorporated into their context model
- If a user consistently ignores or negatively reacts to wildcards from a specific area, that area is deprioritized for future wildcards
- Wildcard frequency is configurable by the user (more/less exploration)

---

## Epic 6: Onboarding & Cold Start

### US-6.1: First-Time Experience

**As a** new user arriving at Insight Surface for the first time,
**I want** a brief, non-blocking introduction that gets me to value within 60 seconds,
**So that** I understand what the product does and immediately see its relevance.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a new user opens Insight Surface, then a lightweight overlay introduces the concept in ≤ 3 screens: "We find the patterns. You explore what matters."
- The overlay shows auto-detected context: "We see you work at [Brand] in [Category]"
- The overlay is skippable at any point
- After the overlay dismisses, the insight stream is immediately visible and loaded
- Total onboarding time: < 30 seconds
- Onboarding only appears once per user (not on subsequent sessions)

---

### US-6.2: Rapid Preference Capture

**As a** new user within my first session,
**I want** the system to quickly learn my priorities through lightweight prompts,
**So that** my stream improves noticeably within my first session.

**Priority**: P0
**Persona**: ALL

**Acceptance Criteria**:

- Given a new user has interacted with 3 insight cards, when a pattern in their interactions is detected, then a non-intrusive prompt appears: "You seem interested in [topic]. Want to see more?"
- The prompt offers: "Yes, more of this" / "Not really" / "Dismiss"
- Given a new user has completed onboarding, when they open the "Quick Focus" panel, then 5-8 category-relevant focus areas are presented for selection
- User can select 1-3 focus areas
- Stream visibly updates within 5 seconds of preference input

---

### US-6.3: Role-Based Stream Tuning

**As a** new user with a specific job function,
**I want** the stream to prioritize insight types that match my role,
**So that** I see the most actionable patterns for my work from day one.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given the system detects or infers the user's role (from account permissions, onboarding, or prompting), when the stream is generated, then insight type weighting is adjusted: Strategist → trends and competitive insights weighted higher; Analyst → anomalies and cross-dimensional correlations weighted higher; Executive → headline market shifts and competitive positioning weighted higher
- Role detection falls back to explicit selection if inference confidence is low
- Role can be changed at any time in settings
- Role-based tuning is a starting point — overridden by personalization as behavioral data accumulates

---

## Epic 7: Power User & Migration

### US-7.1: Source Data Access

**As a** research analyst who needs to verify or extend an insight,
**I want** to access the underlying data behind any insight card,
**So that** I can validate the analysis and perform additional exploration in the traditional query interface.

**Priority**: P0
**Persona**: RA

**Acceptance Criteria**:

- Given any insight card or thread node, when the user clicks "View source data", then the underlying data configuration is shown (variables, filters, segments, time period)
- A "Open in Cross-Tab" action transfers the data configuration to the existing GWI query tool, pre-populated
- The source data view includes the statistical details: exact sample sizes, confidence intervals, and significance levels
- Source data access is available at every level of thread exploration

---

### US-7.2: Guided Migration for Existing Users

**As an** existing GWI user accustomed to cross-tabs and dashboards,
**I want** a smooth introduction to Insight Surface that doesn't disrupt my current workflow,
**So that** I can adopt the new experience at my own pace.

**Priority**: P1
**Persona**: ALL

**Acceptance Criteria**:

- Given an existing user opts into Insight Surface, then Insight Surface becomes the default landing page, but the existing cross-tab and dashboard tools remain accessible from the navigation
- A one-time guided tour highlights key differences: "Instead of building queries, your insights come to you"
- Existing saved audiences, competitive sets, and segments are automatically imported as explicit context
- Users can switch between Insight Surface and the traditional interface at any time
- Usage analytics track adoption patterns to inform the migration timeline

---

### US-7.3: Insight Surface as Complement

**As a** power user who uses both discovery and direct query,
**I want** insights discovered in Insight Surface to inform my cross-tab work and vice versa,
**So that** the two experiences reinforce each other.

**Priority**: P2
**Persona**: RA

**Acceptance Criteria**:

- Given a user runs a cross-tab query in the traditional tool, when they return to Insight Surface, then related insights are boosted in the stream ("Related to your recent analysis of [topic]")
- Given a user saves a cross-tab query, when related patterns emerge in new data waves, then Insight Surface proactively surfaces them
- The context engine treats traditional tool usage as an implicit behavioral signal, equivalent to thread exploration
